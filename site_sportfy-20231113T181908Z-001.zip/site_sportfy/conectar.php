<?php 

  $host = 'localhost';
  $usuario = 'root';
  $senha = '';
  $banco = 'site_sportfy';

  $conexao = new MYSQLI($host , $usuario , $senha , $banco);

  ?>
